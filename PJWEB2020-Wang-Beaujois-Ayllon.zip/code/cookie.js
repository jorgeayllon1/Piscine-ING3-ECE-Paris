const C_ID = '1'
							const C_NOM = 'Wang'
							const C_PAYS = 'Nicaragua'