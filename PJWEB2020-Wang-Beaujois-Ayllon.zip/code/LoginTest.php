<?php

$tableau["id_item"]=array("chemin1","chemin2");
$tableau["autre_id"]=array("chemin3");