<
function auto_cocher(num_value)
{
    var element = document.getElementById('categorie');
    element.value = nameofpackage;
}
	